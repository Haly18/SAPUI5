sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
	"use strict";
	return Controller.extend("Challenge.Challenge.controller.ChallengeView", {
		
		onInit: function () {
			
			var sUrl = "/northwind/V2/northwind/Northwind.svc";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			
			var view = this.getView(); 
			view.setModel(oModel,"employees");
			// oModel.read ("/Employees", {
			// 	success : function(response) {
			// 		// view.setModel (response.results, "employees")
			// 		var oTable = view.byId("table0");
			// 		// oModel.setData(response.results); 
			// 		oTable.setModel(response.results, "employees");
			// 	},
			// 	error : function (response){
					
			// 	}
			// });
		},
		
		employeeSelect : function (e) {
			debugger
		}
	});
});