sap.ui.define([
	"Challenge/Challenge/test/unit/controller/ChallengeView.controller"
], function () {
	"use strict";
});