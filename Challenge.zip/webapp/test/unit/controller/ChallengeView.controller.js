/*global QUnit*/

sap.ui.define([
	"Challenge/Challenge/controller/ChallengeView.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ChallengeView Controller");

	QUnit.test("I should test the ChallengeView controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});